<?php
function parse_booking_date(string $value): ?DateTimeImmutable
{
    $trimmed = trim($value);
    if ($trimmed === "") {
        return null;
    }

    foreach (["M j, Y", "M d, Y", "F j, Y", "F d, Y"] as $format) {
        $date = DateTimeImmutable::createFromFormat("!" . $format, $trimmed);
        if ($date !== false && $date->format($format) === $trimmed) {
            return $date;
        }
    }

    return null;
}

$bookingSaved = false;
$errorMessage = "";
$savedBooking = null;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $equipment = trim($_POST["equipment"] ?? "");
    $pickupInput = trim($_POST["pickup_date"] ?? "");
    $returnInput = trim($_POST["return_date"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $contactName = trim($_POST["contact_name"] ?? "");
    $mobile = trim($_POST["mobile"] ?? "");
    $termsAccepted = ($_POST["terms_acknowledged"] ?? "") === "1";

    $rates = [
        "Sony ZV-E10" => [549, 499, 449],
        "DJI Osmo Pocket 3 Creator Combo" => [549, 499, 449],
        "DJI Osmo Action 4" => [499, 449, 399],
        "Insta360 X5" => [549, 499, 449],
        "Fujifilm Instax Mini Evo" => [299, 249],
        "Fujifilm Instax SQ6" => [299, 249],
    ];

    $pickup = parse_booking_date($pickupInput);
    $return = parse_booking_date($returnInput);
    $today = new DateTimeImmutable("today");

    if ($contactName === "" || strlen($contactName) > 200 || !filter_var($email, FILTER_VALIDATE_EMAIL)
        || strlen($email) > 100 || $mobile === "" || strlen($mobile) > 20) {
        $errorMessage = "Enter a valid contact name, email address, and mobile number.";
    } elseif (!isset($rates[$equipment])) {
        $errorMessage = "Choose a valid camera from the booking list.";
    } elseif ($pickup === null || $return === null || $return < $pickup || $pickup < $today) {
        $errorMessage = "Choose valid pickup and return dates. Pickup must be today or later, and return cannot be before pickup.";
    } elseif (!$termsAccepted) {
        $errorMessage = "Please confirm that you understand this is a rental request.";
    } else {
        $pickupDate = $pickup->format("Y-m-d");
        $returnDate = $return->format("Y-m-d");
        $totalDays = (int) $pickup->diff($return)->days + 1;
        $equipmentRates = $rates[$equipment];

        if ($totalDays >= 7 && count($equipmentRates) === 3) {
            $dailyRate = $equipmentRates[2];
        } elseif ($totalDays >= 4) {
            $dailyRate = $equipmentRates[1];
        } else {
            $dailyRate = $equipmentRates[0];
        }

        $totalAmount = $dailyRate * $totalDays;
        $downpaymentAmount = round($totalAmount / 2, 2);
        $remainingBalance = round($totalAmount - $downpaymentAmount, 2);

        try {
            require_once __DIR__ . "/db.php";

            $columnStmt = $conn->prepare(
                "SELECT DATA_TYPE
                 FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = 'bookings'
                   AND COLUMN_NAME = 'total_days'"
            );
            $columnStmt->execute();
            $columnStmt->bind_result($totalDaysColumnType);
            $hasTotalDaysColumn = $columnStmt->fetch();
            $columnStmt->close();

            if (!$hasTotalDaysColumn || !in_array($totalDaysColumnType, ["int", "smallint", "mediumint", "bigint", "tinyint"], true)) {
                $errorMessage = "The bookings.total_days column must be an integer. Back up the database, then change that column from DATE to INT UNSIGNED before submitting bookings.";
            } else {
                $renterStmt = $conn->prepare("SELECT renter_id FROM renters WHERE email = ?");
                $renterStmt->bind_param("s", $email);
                $renterStmt->execute();
                $renterStmt->bind_result($renterId);
                $hasRenter = $renterStmt->fetch();
                $renterStmt->close();

                if (!$hasRenter) {
                    $errorMessage = "No renter account was found for that email. Register first, or use the email on your renter account.";
                } else {
                    $bookingStmt = $conn->prepare(
                        "INSERT INTO bookings
                            (user_id, equipment_name, start_date, end_date, total_days, total_amount, downpayment_amount, remaining_balance)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
                    );
                    $bookingStmt->bind_param(
                        "isssiddd",
                        $renterId,
                        $equipment,
                        $pickupDate,
                        $returnDate,
                        $totalDays,
                        $totalAmount,
                        $downpaymentAmount,
                        $remainingBalance
                    );
                    $bookingStmt->execute();
                    if ($bookingStmt->affected_rows === 1) {
                        $bookingSaved = true;
                        $savedBooking = [
                            "equipment" => $equipment,
                            "pickupDate" => $pickupDate,
                            "returnDate" => $returnDate,
                            "totalDays" => $totalDays,
                            "totalAmount" => $totalAmount,
                            "downpaymentAmount" => $downpaymentAmount,
                            "remainingBalance" => $remainingBalance,
                        ];
                    } else {
                        $errorMessage = "The booking request was not saved. Please try again.";
                    }
                    $bookingStmt->close();
                }
            }
        } catch (mysqli_sql_exception $exception) {
            error_log("Booking database insert failed: " . $exception->getMessage());
            $errorMessage = "The booking request could not be saved. Check the database connection and bookings table schema, then try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="rental-page">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking - Halo Angel Camera Rental</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="rental-page book-body">

    <header class="site-header shared-guidelines-header">
        <div class="nav-container">
            <a class="logo-brand" href="home.html" aria-label="Halo Angel home">
                <img class="logo-img" src="image/OfficialLogo.png" alt="Halo Angel Logo">
                <span>Halo Angel Camera Rental</span>
            </a>
            <nav class="main-menu" aria-label="Main navigation">
                <a href="catalog.html">Catalog</a>
                <a href="booking.php" aria-current="page">Booking</a>
                <a href="verification.html">Account</a>
                <a href="customer_guidelines.html">Guidelines</a>
            </nav>
            <div class="user-actions">
                <a class="search-btn" href="catalog.html#searchInput" aria-label="Search cameras">
                    <svg viewBox="0 0 24 24" aria-hidden="true">
                        <circle cx="10.8" cy="10.8" r="7.2" />
                        <path d="m16.2 16.2 4.3 4.3" />
                    </svg>
                </a>
                <a class="login-link" href="login.html">Log in</a>
                <a class="signup-btn" href="registration.php" aria-label="Create account">
                    <svg viewBox="0 0 24 24" aria-hidden="true">
                        <circle cx="12" cy="8" r="3.5" />
                        <path d="M5 20c0-3.5 2.8-6 7-6s7 2.5 7 6" />
                    </svg>
                </a>
                <a class="dashboard-link" href="customer_dashboard.html">Dashboard</a>
            </div>
        </div>
    </header>

    <main class="book-container">
        <div class="book-breadcrumb">Home / Booking</div>
        
        <div class="book-top-intro">
            <span class="sub-heading">PLAN YOUR NEXT RENTAL</span>
            <h1 class="page-title">Good gear. Your dates.</h1>
            <p class="subtitle">Choose your camera and preferred rental window. Send a rental request so the team can confirm availability, kit inclusions, and a quote. Equipment includes Sony ZV-E10, DJI Osmo Pocket 3 Creator Combo, DJI Osmo Action 4, Insta360 X5, Instax Mini Evo, and Instax SQ6.</p>
        </div>

        <div class="book-step-nav">
            <span class="book-step-tab active">01 Camera & dates</span>
            <span class="book-step-tab">02 Rental details</span>
            <span class="book-step-tab">03 Request & review</span>
        </div>

        <?php if ($bookingSaved && $savedBooking !== null): ?>
            <section class="book-section" role="status">
                <h2 class="book-sec-title">Booking request saved</h2>
                <p>Your request is pending review. Availability and payment are not confirmed.</p>
                <p><strong>Equipment:</strong> <?php echo htmlspecialchars($savedBooking["equipment"], ENT_QUOTES, "UTF-8"); ?></p>
                <p><strong>Pickup and return:</strong> <?php echo htmlspecialchars($savedBooking["pickupDate"], ENT_QUOTES, "UTF-8"); ?> – <?php echo htmlspecialchars($savedBooking["returnDate"], ENT_QUOTES, "UTF-8"); ?></p>
                <p><strong>Duration:</strong> <?php echo $savedBooking["totalDays"]; ?> day(s)</p>
                <p><strong>Estimated total:</strong> ₱<?php echo number_format($savedBooking["totalAmount"], 2); ?></p>
                <p><strong>Downpayment:</strong> ₱<?php echo number_format($savedBooking["downpaymentAmount"], 2); ?></p>
                <p><strong>Remaining balance:</strong> ₱<?php echo number_format($savedBooking["remainingBalance"], 2); ?></p>
            </section>
        <?php elseif ($errorMessage !== ""): ?>
            <p role="alert" class="book-section" style="color: #b91c1c;">
                <?php echo htmlspecialchars($errorMessage, ENT_QUOTES, "UTF-8"); ?>
            </p>
        <?php endif; ?>

        <form id="bookingMainForm" class="book-main-grid" action="booking.php" method="POST">
            
            <div class="book-form-left">
                <section class="book-section">
                    <h2 class="book-sec-title">01 / Camera & dates</h2>
                    
                    <div class="book-field">
                        <label>Equipment *</label>
                        <select id="equipSelect" name="equipment" required>
                            <option value="Sony ZV-E10" data-t1="549" data-t2="499" data-t3="449" data-kit="Unit, lanyard, silicone cover, charger, bag, 64 GB card" data-img="image/SONY ZVE10.png">Sony ZV-E10</option>
                            <option value="DJI Osmo Pocket 3 Creator Combo" data-t1="549" data-t2="499" data-t3="449" data-kit="Pocket 3, protective cover, handle, mini tripod, wrist strap" data-img="image/POCKET3.png">DJI Osmo Pocket 3 Creator Combo</option>
                            <option value="DJI Osmo Action 4" data-t1="499" data-t2="449" data-t3="399" data-kit="Action 4, battery, frame guard, quick-release adapter, curved base" data-img="image/ACTIONPOCKET4.png">DJI Osmo Action 4</option>
                            <option value="Insta360 X5" data-t1="549" data-t2="499" data-t3="449" data-kit="Insta360 X5 unit, battery, protective pouch, Type-C cable" data-img="image/X360.png">Insta360 X5</option>
                            <option value="Fujifilm Instax Mini Evo" data-t1="299" data-t2="249" data-kit="Instax Mini Evo camera, tempered glass, clear case, lens, protector, lanyard" data-img="image/MINIEVO.png">Fujifilm Instax Mini Evo</option>
                            <option value="Fujifilm Instax SQ6" data-t1="299" data-t2="249" data-kit="Instax SQ6, lanyard" data-img="image/SQ6.png">Fujifilm Instax SQ6</option>
                        </select>
                        <small class="book-subtext">Also explore DJI Osmo Pocket 3 Creator Combo, DJI Osmo Action 4, Insta360 X5, Instax Mini Evo, and Instax SQ6 in the catalog.</small>
                    </div>

                    <div class="book-calendar-box">
                        <div class="book-cal-header">
                            <span id="currentMonthYear" class="book-cal-month">November 2026</span>
                            <div class="book-cal-arrows">
                                <button type="button" class="cal-nav-btn" id="prevMonthBtn">&lt;</button>
                                <button type="button" class="cal-nav-btn" id="nextMonthBtn">&gt;</button>
                            </div>
                        </div>
                        
                        <div class="book-cal-weekdays">
                            <span>Sun</span><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span>
                        </div>

                        <div class="book-cal-days-grid" id="calendarGrid"></div>

                        <div class="book-cal-legend">
                            <span><i class="legend-dot avail"></i> Available</span>
                            <span><i class="legend-dot unavail"></i> Unavailable</span>
                            <span><i class="legend-dot select"></i> Selected</span>
                        </div>
                    </div>

            
                    <div class="book-form-row">
                        <div class="book-field">
                            <label>Pickup date *</label>
                            <input type="text" id="pickupDate" name="pickup_date" placeholder="Select pickup date" required readonly>
                        </div>
                        <div class="book-field">
                            <label>Return date *</label>
                            <input type="text" id="returnDate" name="return_date" placeholder="Select return date" required readonly>
                        </div>
                    </div>
                </section>

                <section class="book-section">
                    <h2 class="book-sec-title">02 / Make your kit</h2>
                    <p class="book-sec-desc">The confirmed gear kit is included at no extra charge. Optionally request add-ons below — these are unpriced proposals; availability, charges, and final inclusions are to be confirmed by the team.</p>

                    <div class="book-addons-grid">
                        <label class="book-checkbox-card">
                            <input type="checkbox" class="addon-chk" name="addons[]" value="Extra battery"> Extra battery (optional, unpriced)
                        </label>
                        <label class="book-checkbox-card">
                            <input type="checkbox" class="addon-chk" name="addons[]" value="Additional memory card"> Additional memory card (optional, unpriced)
                        </label>
                        <label class="book-checkbox-card">
                            <input type="checkbox" class="addon-chk" name="addons[]" value="Tripod"> Tripod (optional, unpriced)
                        </label>
                        <label class="book-checkbox-card">
                            <input type="checkbox" class="addon-chk" name="addons[]" value="Other accessories"> Other accessories (optional, unpriced)
                        </label>
                    </div>

                    <div class="book-field" style="margin-top: 20px;">
                        <label>Shoot details & notes</label>
                        <textarea name="notes" rows="4" placeholder="Tell us about your shoot, preferred accessories, or questions."></textarea>
                    </div>
                </section>

                <section class="book-section">
                    <h2 class="book-sec-title">Pickup & return</h2>
                    <p class="book-sec-desc">Local coordination in Palo Alto, Calamba, Laguna. Exact handover location and times are arranged after review; no pickup is confirmed yet.</p>

                    <div class="book-form-row">
                        <div class="book-field">
                            <label>Preferred pickup time</label>
                            <select name="pickup_time">
                                <option value="">Select time preference</option>
                                <option value="Morning">Morning (8:00 AM - 12:00 PM)</option>
                                <option value="Afternoon">Afternoon (1:00 PM - 5:00 PM)</option>
                            </select>
                        </div>
                        <div class="book-field">
                            <label>Preferred return time</label>
                            <select name="return_time">
                                <option value="">Select time preference</option>
                                <option value="Morning">Morning (8:00 AM - 12:00 PM)</option>
                                <option value="Afternoon">Afternoon (1:00 PM - 5:00 PM)</option>
                            </select>
                        </div>
                    </div>

                    <div class="book-form-row">
                        <div class="book-field">
                            <label>Contact name *</label>
                            <input type="text" name="contact_name" placeholder="Enter your name" required>
                        </div>
                        <div class="book-field">
                            <label>Email address *</label>
                            <input type="email" name="email" placeholder="Enter email address" required>
                        </div>
                    </div>

                    <div class="book-field">
                        <label>Mobile number *</label>
                        <input type="text" name="mobile" placeholder="Enter mobile number" required>
                    </div>
                </section>
            </div>

            <aside class="book-sidebar">
                <div class="book-plan-card">
                    <span class="book-status-tag">Rental request · not confirmed</span>
                    <h2 class="book-plan-title">Your rental plan.</h2>

                    <div class="book-img-preview">
                        <img id="sideCamImg" src="https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&q=80&w=600" alt="Camera">
                    </div>

                    <h3 id="sideCamTitle" class="book-cam-name">Sony ZV-E10</h3>

                    <div class="book-summary-row"><span>Pickup</span><strong id="sidePickup">Not selected</strong></div>
                    <div class="book-summary-row"><span>Return</span><strong id="sideReturn">Not selected</strong></div>
                    <div class="book-summary-row"><span>Duration</span><strong id="sideDuration">0 days</strong></div>

                    <div class="book-summary-block">
                        <span>Included kit</span>
                        <p id="sideKitInclusions">Unit, lanyard, silicone cover, charger, bag, 64 GB card</p>
                    </div>

                    <div class="book-summary-block">
                        <span>Optional add-ons requested</span>
                        <p id="sideAddons">None selected</p>
                    </div>

                    <div class="book-divider"></div>

                    <div class="book-rate-tier-info">
                        <strong>Published rate tiers — <span id="tierCamName">Sony ZV-E10</span></strong>
                        <p id="tierBreakdown">₱549/day (1–3 days) · ₱499/day (1–6 days) · ₱449/day (1–7 days or more)</p>
                        <small>Day ranges shown as published; confirm the applicable tier when booking.</small>
                    </div>

                    <div class="book-divider"></div>

                    <div class="book-summary-row"><span>Rate applied (illustrative)</span><strong id="sideRateApplied">₱0</strong></div>
                    <div class="book-summary-row"><span>Rental subtotal</span><strong id="sideSubtotal">₱0.00</strong></div>
                    <div class="book-summary-row"><span>Optional add-ons</span><strong>Pending confirmation</strong></div>

                    <div class="book-summary-row book-total-row"><span>Base total (excl. add-ons)</span><strong id="sideBaseTotal">₱0.00</strong></div>

                    <div class="book-downpayment-box">
                        <div class="dp-header">50% downpayment, then the balance</div>
                        <div class="dp-row"><span>Downpayment (50%)</span><strong id="sideDP">₱0.00</strong></div>
                        <div class="dp-row"><span>Remaining balance (50%)</span><strong id="sideBalance">₱0.00</strong></div>
                        <p class="dp-note">Base rental estimate only. Accessories outside the confirmed kit require separate confirmation. Not approved or paid.</p>
                    </div>

                    <div class="book-terms-group">
                        <input type="checkbox" id="termsCheck" name="terms_acknowledged" value="1" required>
                        <label for="termsCheck">I understand this is a request, subject to availability, identity review, and final rental terms.</label>
                    </div>

                    <button type="submit" class="book-submit-btn">Submit rental request <i class="fa-solid fa-arrow-up-right-from-square"></i></button>

                    <a href="customer_guidelines.html" class="book-guidelines-link">Review rental guidelines <i class="fa-solid fa-arrow-up-right-from-square" style="font-size: 0.7rem;"></i></a>
                </div>
            </aside>
        </form>
    </main>

    <div class="cta-banner">
        <div>
            <div class="sub-heading dark-sub">READY FOR YOUR NEXT SHOOT?</div>
            <h2>Request a quote.</h2>
        </div>
        <a href="#bookingMainForm" class="btn-quote inline-btn">Request a quote <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
    </div>

    <footer class="footer shared-guidelines-footer">
        <div class="footer-grid">
            <div class="footer-brand">
                <h3>Halo Angel Camera Rental</h3>
                <p>Sony, DJI, Insta360, and Instax rentals.<br>Palo Alto, Calamba, Laguna.</p>
            </div>
            <div class="footer-links">
                <h4>Explore</h4>
                <a href="catalog.html">Catalog</a>
                <a href="booking.php">Booking</a>
                <a href="customer_dashboard.html">Account</a>
                <a href="customer_guidelines.html">Guidelines</a>
            </div>
            <div class="footer-links">
                <h4>About</h4>
                <a href="about_us.html#about">About Halo Angel</a>
                <a href="about_us.html#contact">Palo Alto, Calamba, Laguna</a>
                <a href="about_us.html#contact">Contact</a>
            </div>
            <div class="footer-links">
                <h4>Pathways</h4>
                <a href="customer_dashboard.html#verification">Identity verification</a>
                <a href="customer_dashboard.html#bookings">Booking status</a>
                <a href="customer_guidelines.html#camera-instructions">Camera instructions</a>
            </div>
        </div>
        <div class="footer-bottom">
            <span>© 2026 Halo Angel Camera Rental. Palo Alto, Calamba, Laguna.</span>
            <div class="legal-links">
                <a href="customer_guidelines.html#rental-guidelines">Privacy policy</a>
                <a href="customer_guidelines.html">Guidelines</a>
                <a href="about_us.html#about">About</a>
            </div>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>